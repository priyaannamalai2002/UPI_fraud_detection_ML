import streamlit as st
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from datetime import timedelta

# Load the data
data = pd.read_csv(r"D:\Shiash Info Internship\Datasets\vishing_data.csv")  

# Preprocessing: Convert timedelta columns to numerical features
data['Answer Speed (AVG)'] = pd.to_timedelta(data['Answer Speed (AVG)']).dt.total_seconds()
data['Talk Duration (AVG)'] = pd.to_timedelta(data['Talk Duration (AVG)']).dt.total_seconds()
data['Waiting Time (AVG)'] = pd.to_timedelta(data['Waiting Time (AVG)']).dt.total_seconds()

# Split the data into features (X) and target variable (y)
X = data.drop(columns=['Vishing'])
y = data['Vishing']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize Random Forest Classifier
rf_classifier = RandomForestClassifier(random_state=42)

# Train the model
rf_classifier.fit(X_train, y_train)

# Create Streamlit app
st.title('Machine Learning Application')

# Sidebar
st.sidebar.header('User Input')

# Function to take user input and make predictions
def predict_vishing(answer_rate, abandoned_calls, answer_speed_avg, talk_duration_avg, waiting_time_avg, service_level):
    # Convert time to seconds
    answer_speed_avg = timedelta(minutes=answer_speed_avg).total_seconds()
    talk_duration_avg = timedelta(minutes=talk_duration_avg).total_seconds()
    waiting_time_avg = timedelta(minutes=waiting_time_avg).total_seconds()
    
    # Make prediction
    prediction = rf_classifier.predict([[answer_rate, abandoned_calls, answer_speed_avg, talk_duration_avg, waiting_time_avg, service_level]])
    if prediction[0] == 1:
        return "Vishing High Risk"
    else:
        return "Vishing Low Risk"

# Input fields
abandoned_calls_min = int(data['Abandoned Calls'].min())
abandoned_calls_max = int(data['Abandoned Calls'].max())
abandoned_calls_mean = int(data['Abandoned Calls'].mean())
answer_rate = st.sidebar.number_input('Answer Rate', min_value=data['Answer Rate'].min(), max_value=data['Answer Rate'].max(), value=data['Answer Rate'].mean())
abandoned_calls = st.sidebar.number_input('Abandoned Calls', min_value=abandoned_calls_min, max_value=abandoned_calls_max, value=abandoned_calls_mean)
answer_speed_avg = st.sidebar.number_input('Answer Speed (AVG)', min_value=data['Answer Speed (AVG)'].min(), max_value=data['Answer Speed (AVG)'].max(), value=data['Answer Speed (AVG)'].mean())
talk_duration_avg = st.sidebar.number_input('Talk Duration (AVG)', min_value=data['Talk Duration (AVG)'].min(), max_value=data['Talk Duration (AVG)'].max(), value=data['Talk Duration (AVG)'].mean())
waiting_time_avg = st.sidebar.number_input('Waiting Time (AVG)', min_value=data['Waiting Time (AVG)'].min(), max_value=data['Waiting Time (AVG)'].max(), value=data['Waiting Time (AVG)'].mean())
service_level = st.sidebar.number_input('Service Level (20 Seconds)', min_value=data['Service Level (20 Seconds)'].min(), max_value=data['Service Level (20 Seconds)'].max(), value=data['Service Level (20 Seconds)'].mean())

# Button to make prediction
if st.sidebar.button('Predict'):
    prediction = predict_vishing(answer_rate, abandoned_calls, answer_speed_avg, talk_duration_avg, waiting_time_avg, service_level)
    st.write('Prediction:', prediction)
