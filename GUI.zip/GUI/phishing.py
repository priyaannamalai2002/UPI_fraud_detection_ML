import streamlit as st
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.feature_extraction.text import CountVectorizer

# Load dataset
@st.cache_data()
def load_data():
    dataset_path = r'D:\Shiash Info Internship\Datasets\email_dataset.csv'
    dataset = pd.read_csv(dataset_path)
    return dataset

data = load_data()

# Convert 'Body' column to numerical format using CountVectorizer
vectorizer = CountVectorizer()
X_body = vectorizer.fit_transform(data['Body']).toarray()

# Drop 'Body' column from the original DataFrame
X = data.drop(['Body', 'Additional_Word'], axis=1)

# One-hot encode categorical columns
X = pd.get_dummies(X, columns=['Sender', 'Subject', 'Hyperlink'])

# Concatenate with the numerical 'Body'
X = pd.concat([X, pd.DataFrame(X_body)], axis=1)

# Convert all column names to strings
X.columns = X.columns.astype(str)

# Split features and target
y = data['Additional_Word']

# Train Gradient Boosting Machine (GBM) model
gbm_model = GradientBoostingClassifier()
gbm_model.fit(X, y)

# Streamlit app
st.title("Phishing Email Detector")

st.sidebar.title("Enter Email Information")

# Get unique values from one-hot encoded columns
sender_options = data['Sender'].unique()
subject_options = data['Subject'].unique()
hyperlink_options = data['Hyperlink'].unique()

sender = st.sidebar.selectbox("Sender", sender_options)
subject = st.sidebar.selectbox("Subject", subject_options)
body = st.sidebar.text_area("Body")
hyperlink = st.sidebar.selectbox("Hyperlink", hyperlink_options)

# Preprocess input data
input_data = {
    'Sender': [sender],
    'Subject': [subject],
    'Body': [body],
    'Hyperlink': [hyperlink]
}
input_df = pd.DataFrame(input_data)

# One-hot encode categorical columns
input_df = pd.get_dummies(input_df, columns=['Sender', 'Subject', 'Hyperlink'])

# Ensure input data has the same columns as training data
missing_cols = set(X.columns) - set(input_df.columns)
for col in missing_cols:
    input_df[col] = 0

# Reorder columns to match training data
input_df = input_df[X.columns]

# Verify that the 'Body' column is present in input_df
if 'Body' not in input_df.columns:
    st.error("The 'Body' column is missing in the input data.")
    st.stop()

# Convert 'Body' column to numerical format using CountVectorizer
input_body = vectorizer.transform(input_df['Body'].fillna('')).toarray()

# Drop 'Body' column from the original DataFrame and concatenate with the numerical 'Body'
input_X = input_df.drop('Body', axis=1)
input_X = pd.concat([input_X, pd.DataFrame(input_body)], axis=1)

# Make prediction
prediction = gbm_model.predict(input_X)

st.subheader("Prediction")
if prediction[0] == 'transaction':
    st.success("Safe Email!")
else:
    st.error("Potential Phishing Email!")
