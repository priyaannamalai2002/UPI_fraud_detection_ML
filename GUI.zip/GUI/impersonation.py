import pandas as pd
import numpy as np
import streamlit as st
from sklearn.preprocessing import LabelEncoder, StandardScaler
from keras.models import Sequential
from keras.layers import LSTM, Dense, Dropout
import os

# Function to preprocess user input
def preprocess_input(user_input):
    # Create a DataFrame from the user input
    user_data = pd.DataFrame(user_input, index=[0])
    
    # Convert categorical variables to numeric using LabelEncoder
    for col in ['Sender\'s Identity', 'Message Content', 'Language', 'Receiver\'s UPI ID', 'Location']:
        label_encoder = LabelEncoder()
        user_data[col] = label_encoder.fit_transform(user_data[col])
    
    # Extract the hour from the Time of Transaction and drop the original column
    user_data['Time of Transaction'] = pd.to_datetime(user_data['Time of Transaction'])
    user_data['Hour of Transaction'] = user_data['Time of Transaction'].dt.hour
    user_data.drop(columns=['Time of Transaction'], inplace=True)
    
    # Scale numerical features (excluding 'Time of Transaction')
    scaler = StandardScaler()
    user_data_scaled = scaler.fit_transform(user_data)
    
    return user_data_scaled

# Load the pre-trained LSTM model
@st.cache(allow_output_mutation=True)
def load_model():
    model = Sequential()
    model.add(LSTM(units=50, return_sequences=True, input_shape=(None, 7)))  # Adjust input shape
    model.add(Dropout(0.2))
    model.add(LSTM(units=50, return_sequences=True))
    model.add(Dropout(0.2))
    model.add(LSTM(units=50))
    model.add(Dropout(0.2))
    model.add(Dense(units=1, activation='sigmoid'))

    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

    model_path = "fraud_detection_model_weights.h5"
    if os.path.exists(model_path):
        model.load_weights(model_path)  # Load model weights
    else:
        st.error("Model weights not found. Please make sure the model is trained and the weights file exists.")

    return model

# Streamlit GUI
st.title("Fraud Detection")
st.write("Enter the following details to predict if the transaction is fraudulent or not.")

# Input fields for user-defined feature values
user_input = {}
user_input['Sender\'s Identity'] = st.selectbox("Sender's Identity", ['Alice', 'Bob', 'Carol', 'David', 'Eva', 'Frank', 'Grace', 'Hannah'])
user_input['Message Content'] = st.text_input("Message Content", "Please send money urgently")
user_input['Language'] = st.selectbox("Language", ['English', 'Hindi'])
user_input['Transaction Amount'] = st.number_input("Transaction Amount", value=5000)
user_input['Receiver\'s UPI ID'] = st.text_input("Receiver's UPI ID", "xyz@upi")
user_input['Time of Transaction'] = st.text_input("Time of Transaction", "4/7/2024 9:30")
user_input['Location'] = st.text_input("Location", "Mumbai")

# Predict button
if st.button("Predict"):
    # Preprocess user input
    user_data_scaled = preprocess_input(user_input)

    # Load pre-trained LSTM model
    model = load_model()

    # Make prediction
    if model is not None:
        prediction = model.predict(user_data_scaled.reshape(1, 1, -1))  # Reshape input for LSTM

        # Display prediction
        if prediction is not None:
            if prediction >= 0.5:
                st.write("Prediction: This transaction is likely fraudulent.")
            else:
                st.write("Prediction: This transaction is likely not fraudulent.")
