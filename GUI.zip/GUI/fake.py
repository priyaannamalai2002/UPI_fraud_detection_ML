import streamlit as st
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC

# Load the dataset
file_path = "D:/Shiash Info Internship/Datasets/fake_payments_dataset.csv"
data = pd.read_csv(file_path)

# Sidebar title
st.sidebar.title('User Input')

# Input fields
transaction_amount = st.sidebar.number_input('Transaction Amount', min_value=data['Transaction_Amount'].min(), max_value=data['Transaction_Amount'].max(), value=data['Transaction_Amount'].mean())
transaction_frequency = st.sidebar.slider('Transaction Frequency', min_value=int(data['Transaction_Frequency'].min()), max_value=int(data['Transaction_Frequency'].max()), value=int(data['Transaction_Frequency'].mean()))
merchant_rating = st.sidebar.slider('Merchant Rating', min_value=int(data['Merchant_Rating'].min()), max_value=int(data['Merchant_Rating'].max()), value=int(data['Merchant_Rating'].mean()))
customer_age = st.sidebar.slider('Customer Age', min_value=int(data['Customer_Age'].min()), max_value=int(data['Customer_Age'].max()), value=int(data['Customer_Age'].mean()))
transaction_location_international = st.sidebar.checkbox('Transaction Location International')
transaction_location_local = st.sidebar.checkbox('Transaction Location Local')

# Prepare input data for prediction
input_data = pd.DataFrame({
    'Transaction_Amount': [transaction_amount],
    'Transaction_Frequency': [transaction_frequency],
    'Merchant_Rating': [merchant_rating],
    'Customer_Age': [customer_age],
    'Transaction_Location_International': [transaction_location_international],
    'Transaction_Location_Local': [transaction_location_local]
})

# Split features and target
X = data.drop('Receipt_Details', axis=1)
y = data['Receipt_Details']

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train Support Vector Machine (SVM) model
svm_model = SVC(kernel='linear', probability=True)
svm_model.fit(X_train, y_train)

# Make prediction
prediction = svm_model.predict(input_data)
prediction_proba = svm_model.predict_proba(input_data)[:, 1]

# Display prediction result
st.title('Fake Payment Detection')

if prediction[0] == 1:
    st.write('Prediction: Fake Payment')
else:
    st.write('Prediction: Genuine Payment')


