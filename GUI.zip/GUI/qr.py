import os
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models
from sklearn.model_selection import train_test_split
import streamlit as st

# Load images and labels
def load_data(directory):
    images = []
    labels = []
    for filename in os.listdir(directory):
        img = tf.keras.preprocessing.image.load_img(os.path.join(directory, filename), target_size=(224, 224))
        img_array = tf.keras.preprocessing.image.img_to_array(img)
        images.append(img_array)
        labels.append(1 if filename.startswith('real') else 0)  # 1 for real QR codes, 0 for fake
    return np.array(images), np.array(labels)

# Path to the directory containing generated QR codes
dataset_dir = r'D:\Shiash Info Internship\Datasets\qr_dataset'  # Update this with the correct directory path

# Load data
images, labels = load_data(dataset_dir)

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(images, labels, test_size=0.2, random_state=42)

# Create a CNN model
model = models.Sequential([
    layers.Conv2D(32, (3, 3), activation='relu', input_shape=(224, 224, 3)),
    layers.MaxPooling2D((2, 2)),
    layers.Conv2D(64, (3, 3), activation='relu'),
    layers.MaxPooling2D((2, 2)),
    layers.Conv2D(128, (3, 3), activation='relu'),
    layers.MaxPooling2D((2, 2)),
    layers.Flatten(),
    layers.Dense(128, activation='relu'),
    layers.Dropout(0.5),
    layers.Dense(1, activation='sigmoid')
])
# Compile the model
model.compile(optimizer='adam',
              loss='binary_crossentropy',
              metrics=['accuracy'])

# Train the model
model.fit(X_train, y_train, epochs=10, batch_size=32, validation_split=0.2)

# Function to make predictions
def predict_image(image):
    img = tf.keras.preprocessing.image.load_img(image, target_size=(224, 224))
    img_array = tf.keras.preprocessing.image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)  # Expand dimensions to match model input shape
    prediction = model.predict(img_array)
    return prediction[0][0]

# Streamlit GUI
st.title("QR Code Classifier")
st.write("Upload an image to classify it as real or fake.")

uploaded_file = st.file_uploader("Choose an image...", type="jpg")

if uploaded_file is not None:
    st.image(uploaded_file, caption='Uploaded Image.', use_column_width=True)
    prediction = predict_image(uploaded_file)
    if prediction >= 0.5:
        st.write("Prediction: This is a real QR code.")
    else:
        st.write("Prediction: This is a fake QR code.")
